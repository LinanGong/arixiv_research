__author__ = 'Kay'

import requests

r = requests.get('https://papers.nips.cc')
print(r.content)
