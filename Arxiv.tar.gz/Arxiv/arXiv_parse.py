__author__ = 'Kay'

#!/usr/bin/python
# -*- coding: UTF-8 -*-

import xml.sax
out_file = open('arxiv_parsed_data/data.txt', 'w')
class EntryHandler(xml.sax.ContentHandler ):
    def __init__(self):
       self.CurrentData = ""
       self.published = ""
       self.title = ""
       self.author = []
       self.category = ""

    # start event
    def startElement(self, tag, attributes):
        self.CurrentData = tag
        # print self.CurrentData
        if tag == "entry":
            print ("*****entry*****")
            self.title = ""
            # title = attributes["title"]
            # print "Title:", title
        elif tag == "arxiv:primary_category":
            self.category = attributes["term"]
            print ("Category:", self.category)

    # end event
    def endElement(self, tag):
        if tag == "entry":
            author = ""
            for name in self.author:
                author = author + name + ","
            data = self.title + '+' + author + '+' + self.published + '\n'
            out_file.write(data)

            self.entry = {}
            self.author = []
        elif tag == "published":
            print ("Published:", self.published)
            # self.entry["published"] = self.published.split('T')[0]
        elif tag == "title":
            print ("Title:", self.title)
            # self.entry["title"] = self.title
        elif tag == "author":
            print ("Author:", self.author)
            # self.entry["author"] = self.author
        self.CurrentData = ""

    # content event
    def characters(self, content):
      if self.CurrentData == "published":
         self.published = content.split('T')[0]
      elif self.CurrentData == "title":
         self.title = content
      elif self.CurrentData == "name":
         self.author.append(content)


if ( __name__ == "__main__"):

   parser = xml.sax.make_parser()
   # turn off namepsaces
   parser.setFeature(xml.sax.handler.feature_namespaces, 0)

   # rewrite contentHandler
   Handler = EntryHandler()
   parser.setContentHandler( Handler )

   parser.parse("arxivdata/cs.AI.xml")
