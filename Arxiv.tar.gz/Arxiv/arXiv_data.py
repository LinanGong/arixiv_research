__author__ = 'Kay'

import urllib


def get_cat_list(in_name = 'arxivdata/cat_list.txt'):
    cat_list = []
    for line in open(in_name).readlines():
        cat_list.append(line.strip())
    return cat_list


cat_list = get_cat_list()

for cat in cat_list:
    data = []
    print(cat)
    out_file = open('arxivdata/' + cat + '.xml', 'w')
    url = 'http://export.arxiv.org/api/query?search_query=cat:%s&sortBy=submittedDate&sortOrder=descending&start=0&max_results=1000' % cat
    data = urllib.urlopen(url).read()
    # print data
    out_file.write(data)
    url = 'http://export.arxiv.org/api/query?search_query=cat:%s&sortBy=submittedDate&sortOrder=descending&start=1000&max_results=2000' % cat
    data = urllib.urlopen(url).read()
    # print data
    out_file.write(data)