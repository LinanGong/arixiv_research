# -*- coding: utf-8 -*-
__author__ = 'Kay'

import xml.sax
import re
import codecs


class EntryHandler(xml.sax.ContentHandler):

    def __init__(self):
        self.out_file = codecs.open('arxiv_articles.txt', 'a', 'utf-8')
        self.CurrentData = ""
        self.title = ""
        self.author = ""
        self.category = ""
        self.submit = ""
        self.flag = 0

    # start event
    def startElement(self, tag, attributes):
        self.CurrentData = tag
        print "current:", self.CurrentData

        if tag == "metadata":
            print ("*****new record*****")

        elif tag == "version" and attributes["version"] == "v1":
            self.flag = 1
        elif tag == "date":
            print "date:", self.flag
        else:
            self.flag = 0
            print "tag:", tag

    # end event
    def endElement(self, tag):
        if tag == "metadata":
            date = self.submit.split(' ')
            self.submit = date[1]+'-'+date[2]+'-'+date[3]
            data = self.title + ' ### ' + self.author + ' ### ' + self.category + ' ### ' + self.submit + '\n'
            self.out_file.write(data)
            self.title = ""
            self.author = ""
            self.submit = ""
            self.category = ""
            self.CurrentData = ""
            self.flag = 0

        elif tag == "title":
            self.title = re.sub('\n +', ' ', self.title)
            print ("Title:", self.title)

        elif tag == "authors":
            self.author = re.sub('\n +', ' ', self.author)
            print ("Author:", self.author)

        elif tag == "categories":
            print ("Category:", self.category)


    # content event
    def characters(self, content):
        if self.CurrentData == "date" and self.flag == 1:
            print "submit:"
            self.submit = self.submit + content
            print self.submit
        elif self.CurrentData == "title":
            self.title = self.title + content
            print self.title
        elif self.CurrentData == "authors":
            self.author = self.author + content
            print self.author
        elif self.CurrentData == "categories":
            self.category = content
            print content




if ( __name__ == "__main__"):

    parser = xml.sax.make_parser()
    # turn off namepsaces
    parser.setFeature(xml.sax.handler.feature_namespaces, 0)

    # rewrite contentHandler
    Handler = EntryHandler()
    parser.setContentHandler( Handler )

    i = 1
    while i < 110:
        file = '/Users/Kay/Project/Arxive/datafiles/data' + str(i) + '.xml'
        print file
        parser.parse(file)
        i += 1

    Handler.out_file.close()
