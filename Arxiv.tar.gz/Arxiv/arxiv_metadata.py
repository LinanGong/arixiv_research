__author__ = 'Kay'

import urllib
import time

url = "http://export.arxiv.org/oai2?verb=ListRecords&from=1993-01-01&set=cs&metadataPrefix=arXivRaw"
data = urllib.urlopen(url).read()
out_file = open('data1.xml', 'w')
out_file.write(data)

# url2 = "http://export.arxiv.org/oai2?verb=ListRecords&resumptionToken=1219058|8001"
# data2 = urllib.urlopen(url2).read()
# out_file = open('data9.xml', 'w')
# out_file.write(data2)

n = 1
while n <= 109:
    url2 = "http://export.arxiv.org/oai2?verb=ListRecords&resumptionToken=1219662|%s001" % str(n)
    data2 = urllib.urlopen(url2).read()
    n = n + 1
    out_file = open('data'+ str(n) + '.xml', 'w')
    out_file.write(data2)
    print n
    time.sleep(25)
    print "wake"