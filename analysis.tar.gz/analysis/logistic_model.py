__author__ = 'Kay'

import json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import cross_val_score
from sklearn.externals import joblib


def get_training_data(conference):
    with open('samples/train_'+conference+'.json', 'r') as f:
        cons = json.load(f)

    x = []
    y = []
    for con in cons:

        x.append([con['a_sim'], con['t_sim']])
        y.append(1 if 'matched' in con else 0)

    return np.array(x), np.array(y)


def get_all_training_data():
    cons = ['ACL', 'CHI', 'FOCS', 'ICML', 'ICSE', 'NIPS', 'SIGKDD', 'SIGMOD']
    x = []
    y = []
    for con in cons:
        with open('samples/train_'+con+'.json', 'r') as f:
            c = json.load(f)
        for item in c:
            x.append([item['a_sim'], item['t_sim']])
            y.append(1 if 'matched' in item else 0)
    return np.array(x), np.array(y)


def train_model(X, y, model_name=None):
    print(len(X), len(y))
    LR = LogisticRegression()
    LR.fit(X, y)
    print LR.coef_, LR.intercept_
    print LR.score(X, y)
    if not model_name is None:
        joblib.dump(LR, model_name)


def cross_val(X, y):
    LR = LogisticRegression()
    scores = cross_val_score(LR, X, y, cv=5)
    # print scores
    print scores.mean()


def get_sim_data(conference):
    with open('sim_files/' + conference + '_sim.json') as f:
        con = json.load(f)
    X = []
    for item in con:
        X.append([item['a_sim'], item['t_sim']])

    return np.array(X)


def apply_model(X, model_name):
    model = joblib.load(model_name)
    y = model.predict(X)
    print y, sum(y)
    return y


def evaluate_model(X_test, y_test, model_name):
    model = joblib.load(model_name)
    score = model.score(X_test, y_test)
    print score


def get_train_test_data(X, y):
    if len(X) != len(y):
        return -1

    length = len(X)
    test_i = np.random.choice(length, length / 5)
    train_i = np.setdiff1d(np.arange(length), test_i)

    X_train = []
    X_test = []
    for i in list(train_i):
        X_train.append([X[i][0], X[i][1]])

    for i in list(test_i):
        X_test.append([X[i][0], X[i][1]])

    X_train = np.array(X_train)
    X_test = np.array(X_test)
    y_train = y.take(train_i)
    y_test = y.take(test_i)

    return X_train, X_test, y_train, y_test



if __name__ == '__main__':
    # cons = ['ACL', 'CHI', 'FOCS', 'ICML', 'ICSE', 'NIPS', 'SIGKDD', 'SIGMOD']
    # for con in cons:
    #     print con
    #     # train_model(con)
    #     cross_val(con)

    X, y = get_all_training_data()
    X_train, X_test, y_train, y_test = get_train_test_data(X, y)
    # print(X_train, y_train)
    train_model(X_train, y_train, 'model/all2.mod')
    evaluate_model(X_test, y_test, 'model/all2.mod')
    cross_val(X_train, y_train)

    # X = get_sim_data('AAMAS')
    # apply_model(X, 'model/all.mod')