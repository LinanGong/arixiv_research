__author__ = 'Kay'

import json
import random
import os
import pylab as pl


def load_data(conference, number):

    print 'start!'
    with open('data_files/'+conference+'_title.json') as f1:
        title = json.load(f1)
    with open('data_files/'+conference+'_authors.json') as f2:
        authors = json.load(f2)

    print 'load done!'

    x = [i for i in range(0, len(title))]
    index = random.sample(x, 20)

    samplefile = open('evaluate/' + str(number) +'.json', 'w')
    samplefile.write('[\n')
    samples = {}
    for i in index:
        samples['title1'] = title[i]['paper1']['title']
        samples['title2'] = title[i]['paper2']['title']
        samples['year1'] = title[i]['paper1']['year']
        samples['year2'] = title[i]['paper2']['submit']
        samples['title_similarity'] = title[i]['similarity']
        samples['authors1'] = authors[i]['paper1']['authors']
        samples['authors2'] = authors[i]['paper2']['authors']
        samples['authors_similarity'] = authors[i]['similarity']
        if index.index(i) < 19:
            samplefile.write(json.dumps(samples)+',\n')
        else:
            samplefile.write(json.dumps(samples)+'\n')
    samplefile.write(']')
    samplefile.close()


def average_performance(t_threshold, a_threshold):
    dirs = os.listdir('evaluate')
    t_threshold -= 0.01
    a_threshold -= 0.01
    # Precision, Recall = [], []
    TP, FP, TN, FN = 0.0, 0.0, 0.0, 0.0

    for file in dirs:
        with open('evaluate/'+file) as sample_file:
            sample = json.load(sample_file)
        print "threshold:", t_threshold, a_threshold

        for item in sample:
            print "t_sim: ", item['title_similarity'], " a_sim: ", item['authors_similarity']
            if (item['title_similarity'] >= t_threshold) and (item['authors_similarity'] >= a_threshold):
                print "positive"
                if 'match' in item:
                    TP += 1
                else:
                    FP += 1
            else:
                if 'match' in item:
                    FN += 1
                else:
                    TN += 1
        print "TP: ", TP, " FP: ", FP, " FN: ", FN, " TN: ", TN
    if TP + FP == 0:
        FP += 0.01
        # Precision.append(TP/(TP+FP))
        # Recall.append(TP/(TP+FN))
    Precision = TP/(TP+FP)
    Recall = TP/(TP+FN)

    # P, R = sum(Precision)/len(Precision), sum(Recall)/len(Recall)

    return Precision, Recall


def plotting():

    t_value = 0.5
    i = 1
    while t_value < 1.05:
        P, R = [], []
        a_value = 0.5
        while a_value < 1.05:
            pre, recall = average_performance(t_value, a_value)
            # print pre, recall
            P.append(pre)
            R.append(recall)
            a_value += 0.05
        print t_value, a_value
        print P,'\n',R
        ax = pl.subplot(4,3,i)
        ax.plot(R, P, 'o-')
        title = "t = " + str(t_value)
        pl.title(title)
        # pl.xlim([0.5, 1.05])
        # pl.ylim([0, 1.05])
        i += 1
        t_value += 0.05

    pl.show()


def produce_sample(conference):
    with open('sim_files/'+conference+'_sim.json') as f1:
        con = json.load(f1)
    print 'load ', conference, len(con)

    entity1 = []
    entity2 = []
    entity3 = []

    for item in con:
        if item['a_sim'] > 0 and 0.5 > item['t_sim'] > 0:
            entity1.append(item)
        elif item['a_sim'] > 0 and 0.75 > item['t_sim'] >= 0.5:
            entity2.append(item)
        elif item['a_sim'] > 0 and item['t_sim'] >= 0.75:
            entity3.append(item)

    print 'processed! ', len(entity1), len(entity2), len(entity3)

    index1 = random.sample(range(0, len(entity1)), 35)
    print index1
    if len(entity2) < 35:
        index2 = random.sample(range(0, len(entity2)), len(entity2))
    else:
        index2 = random.sample(range(0, len(entity2)), 35)
    if len(entity3) < 35:
        index3 = random.sample(range(0, len(entity3)), len(entity3))
    else:
        index3 = random.sample(range(0, len(entity3)), 35)

    samplefile = open('samples/test_' + conference +'.json', 'w')
    samplefile.write('[\n')
    samples = {}
    index = [index1, index2, index3]
    entity = [entity1, entity2, entity3]
    for i in range(0, 3):
        for x in index[i]:
            samples['title1'] = entity[i][x]['paper1']['title']
            samples['title2'] = entity[i][x]['paper2']['title']
            samples['year1'] = entity[i][x]['paper1']['year']
            samples['year2'] = entity[i][x]['paper2']['submit']
            samples['t_sim'] = entity[i][x]['t_sim']
            samples['authors1'] = entity[i][x]['paper1']['authors']
            samples['authors2'] = entity[i][x]['paper2']['authors']
            samples['a_sim'] = entity[i][x]['a_sim']
            if i == 2 and index[i].index(x) == len(index[i])-1:
                samplefile.write(json.dumps(samples)+'\n')
            else:
                samplefile.write(json.dumps(samples)+',\n')
    samplefile.write(']')
    samplefile.close()


def performance(conference, t_threshold, a_threshold):

    t_threshold -= 0.01
    a_threshold -= 0.01

    TP, FP, TN, FN = 0.0, 0.0, 0.0, 0.0

    with open('samples/train_'+conference+'.json') as sample_file:
        sample = json.load(sample_file)
    print "threshold:", t_threshold, a_threshold

    for item in sample:
        print "t_sim: ", item['t_sim'], " a_sim: ", item['a_sim']
        if (item['t_sim'] >= t_threshold) and (item['a_sim'] >= a_threshold):
            print "positive"
            if 'matched' in item:
                TP += 1
            else:
                FP += 1
        else:
            if 'matched' in item:
                FN += 1
            else:
                TN += 1
    print "TP: ", TP, " FP: ", FP, " FN: ", FN, " TN: ", TN
    if TP + FP == 0:
        FP += 0.01

    Precision = TP/(TP+FP)
    Recall = TP/(TP+FN)

    return Precision, Recall


def plotting(conference):

    t_value = 0.5
    i = 1
    while t_value < 1.05:
        P, R = [], []
        a_value = 0.5
        while a_value < 1.05:
            pre, recall = performance(conference, t_value, a_value)
            # print pre, recall
            P.append(pre)
            R.append(recall)
            a_value += 0.05
        print t_value, a_value
        print P,'\n',R
        ax = pl.subplot(2,3,i)
        ax.plot(R, P, 'o-')
        title = "t = " + str(t_value)
        pl.title(title)
        # pl.xlim([0.5, 1.05])
        # pl.ylim([0, 1.05])
        i += 1
        t_value += 0.1

    pl.show()


if __name__=='__main__':
    # for n in range(1, 11):
    #     load_data('NIPS', n)
    # average_performance()

    # plotting()
    # cons = ['ACL', 'CHI', 'NIPS', 'FOCS', 'SIGKDD', 'SIGMOD', 'ICML', 'ICSE']
    # for con in cons:
    # produce_sample('SIGMOD')
    plotting('NIPS')

