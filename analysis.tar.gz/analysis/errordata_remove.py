__author__ = 'Kay'

import json

with open('/Users/Kay/Project/Scraper/conference/SIGGRAPH2015.json') as f:
    data = json.load(f)

new_f = open('/Users/Kay/Project/Scraper/conference/SIGGRAPH2015.json', 'w')
new_f.write('[\n')
for item in data:
    if item['authors']:
        text = json.dumps(item)
        new_f.write(text)
        if data.index(item) < len(data)-1:
            new_f.write(',')
        new_f.write('\n')

new_f.write(']')
new_f.close()