__author__ = 'Kay'
import json
from nltk.corpus import stopwords
from nltk.tokenize import wordpunct_tokenize
from nltk.stem.porter import PorterStemmer
import os
import re

def load_arxiv_data():
    arxiv = []
    print "load arXiv data ..."
    for line in open('/Users/Kay/Project/Scraper/arXiv/arxiv_articles.txt'):
        item = {}
        data = line.strip().split(' ### ')
        item['title'] = data[0]
        item['authors'] = data[1]
        item['category'] = data[2]
        item['submit'] = data[3]
        arxiv.append(item)
    print "load successful"
    return arxiv


def process_arxiv_data():
    arxiv = load_arxiv_data()
    stop_words = set(stopwords.words('english'))
    stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])
    x = 1
    for item in arxiv:
        print x
        title = item['title'].lower()
        titlelist = [i for i in wordpunct_tokenize(title) if i not in stop_words]
        authors = re.sub(r'\(\w+((-|\s|,|/|&|\'|\.|\"|;)*\w*|\(\w+|\s|\d+\)*)*\)', '', item['authors']).lower()
        authorlist = [i for i in wordpunct_tokenize(authors) if i not in stop_words]
        item['titlelist'] = titlelist
        item['authorlist'] = authorlist
        x += 1
    print 'arxiv processed!'

    # with open('/Users/Kay/Project/Scraper/arXiv/arxiv.json', 'w') as f:
    #     json.dump(arxiv, f)
    return arxiv


def load_conference_data(conference):
    dirs = os.listdir('/Users/Kay/Project/Scraper/conference')
    print dirs
    conf = []
    for dir in dirs:
        if dir.startswith(conference):
            with open('/Users/Kay/Project/Scraper/conference/'+dir) as jsonfile:
                con = json.load(jsonfile)
                print con
                conf.append(con)
    return conf


def process_paper(conference):

    cons = load_conference_data(conference)

    stop_words = set(stopwords.words('english'))
    stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])

    conf = []
    for con in cons:
        for article in con:
            title = article['title'].encode('utf-8').lower()
            titlelist = [i for i in wordpunct_tokenize(title) if i not in stop_words]
            article['titlelist'] = titlelist
            authors = (' '.join(article['authors'])).encode('utf-8').lower()
            authorlist = [i for i in wordpunct_tokenize(authors) if i not in stop_words]
            article['authorlist'] = authorlist
            conf.append(article)
    print conference + ' processed!'

    return conf


def compute_similarity(conference):
    # with open('/Users/Kay/Project/Scraper/arXiv/arxiv.json', 'r') as f:
    #     arxiv = json.load(f)
    arxiv = process_arxiv_data()
    # print arxiv
    conf = process_paper(conference)
    json_file = open('sim_files/' + conference + '_sim.json', 'w')
    json_file.write('[\n')
    txt_file = open('sim_files/' + conference + '_sim.txt', 'w')

    i = 1
    for article in conf:

        title1 = article['titlelist']
        authors1 = article['authorlist']

        # title_sim = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        # paper = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        sim = []
        papers = []
        for item in arxiv:

            title2 = item['titlelist']

            count = 0
            for word in title1:
                if word in title2:
                    count += 1
            similarity = 2*float(count)/(len(title1)+len(title2))

            sim.append(similarity)
            papers.append(item)

        title_sim = []
        paper = []
        for x in range(0, 10):
            index = sim.index(max(sim))
            title_sim.append(max(sim))
            paper.append(papers[index])
            sim.remove(sim[index])
            papers.remove(papers[index])

            # for index in range(0, 10):
            #     if similarity >= title_sim[index]:
            #         if index < 9:
            #             title_sim[index+1:10] = title_sim[index:9]
            #             paper[index+1:10] = paper[index:9]
            #         title_sim[index] = similarity
            #         paper[index] = item
            #         break
        # print 'title sim: ', title_sim

        authors_sim = []
        for item in paper:
            authors2 = item['authorlist']

            count = 0
            for word in authors1:
                if word in authors2:
                    count += 1
            similarity = 2*float(count)/(len(authors1)+len(authors2))
            authors_sim.append(similarity)


        a_max = max(authors_sim)
        n = authors_sim.index(a_max)

        # print 'authors sim: ', authors_sim


        compare = {}
        compare['paper1'] = article
        compare['paper2'] = paper[n]
        compare['t_sim'] = title_sim[n]
        compare['a_sim'] = a_max

        print i
        if i < len(conf):
            json_file.write(json.dumps(compare) + ',\n')
        else:
            json_file.write(json.dumps(compare) + '\n')
        i += 1

        string = article['title'].encode('utf-8') + '---' + str(title_sim[n]) + '---' + paper[n]['title'] + '\n'

        txt_file.write(string)

    json_file.write(']')
    json_file.close()
    txt_file.close()



# def remove_title_stopwords(conference):
#     arxiv = load_arxiv_data()
#     cons = load_conference_data(conference)
#
#     stop_words = set(stopwords.words('english'))
#     stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])
#
#     for item in arxiv:
#         title = item['title'].lower()
#         wordlist = [i for i in wordpunct_tokenize(title) if i not in stop_words]
#
#         item['wordlist'] = wordlist
#     print 'arxiv processed!'
#
#     conf = []
#     for con in cons:
#         for article in con:
#             title = article['title'].encode('utf-8').lower()
#             wordlist = [i for i in wordpunct_tokenize(title) if i not in stop_words]
#             article['wordlist'] = wordlist
#             conf.append(article)
#     print conference + ' processed!'
#
#     return arxiv, conf


# def process_authors(conference):
#     arxiv = load_arxiv_data()
#     cons = load_conference_data(conference)
#
#     stop_words = set(stopwords.words('english'))
#     stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])
#
#     for item in arxiv:
#         authors = re.sub(r'\(.*\)', '', item['authors']).lower()
#         wordlist = [i for i in wordpunct_tokenize(authors) if i not in stop_words]
#         item['wordlist'] = wordlist
#     print 'arxiv processed!'
#
#     conf = []
#     for con in cons:
#         for article in con:
#             authors = (' '.join(article['authors'])).encode('utf-8').lower()
#             wordlist = [i for i in wordpunct_tokenize(authors) if i not in stop_words]
#             article['wordlist'] = wordlist
#             conf.append(article)
#     print conference + ' processed!'
#
#     return arxiv, conf


# def match_title(conference):
#     arxiv, conf = remove_title_stopwords(conference)
#
#     json_file = open('data_files/' + conference + '_title.json', 'w')
#     json_file.write('[\n')
#     txt_file = open('data_files/' + conference + '_title.txt', 'w')
#
#     i = 1
#     for article in conf:
#
#         title1 = article['wordlist']
#
#         value = 0.0
#
#         for item in arxiv:
#             year = item['submit'].split('-')[2]
#             if year == article['year'] or int(year) == int(article['year'])-1 or int(year) == int(article['year'])+1:
#                 title2 = item['wordlist']
#
#                 count = 0
#                 for word in title2:
#                     if word in title1:
#                         count += 1
#                 similarity = 2*float(count)/(len(title1)+len(title2))
#                 if similarity > value:
#                     value = similarity
#                     sim = [item, similarity]
#
#         compare = {}
#         compare['paper1'] = article
#         compare['paper2'] = sim[0]
#         compare['similarity'] = sim[1]
#
#         print i
#         if i < len(conf):
#             json_file.write(json.dumps(compare) + ',\n')
#         else:
#             json_file.write(json.dumps(compare) + '\n')
#         i += 1
#
#         txt_file.write(article['title'].encode('utf-8') + '---' + str(sim[1]) + '---' + sim[0]['title'] + '\n')
#
#     json_file.write(']')
#     json_file.close()
#     txt_file.close()
#
#
# def match_authors(conference):
#     arxiv, conf = process_authors(conference)
#
#     json_file = open('data_files/' + conference + '_authors.json', 'w')
#     json_file.write('[\n')
#     txt_file = open('data_files/' + conference + '_authors.txt', 'w')
#
#     i = 1
#     for article in conf:
#
#         authors1 = article['wordlist']
#
#         value = 0.0
#         sim = []
#         for item in arxiv:
#             year = item['submit'].split('-')[2]
#
#             if year == article['year'] or int(year) == int(article['year'])-1 or int(year) == int(article['year'])+1:
#                 authors2 = item['wordlist']
#
#                 count = 0
#                 for word in authors2:
#                     if word in authors1:
#                         count += 1
#                 similarity = 2*float(count)/(len(authors1)+len(authors2))
#                 if similarity > value:
#                     value = similarity
#                     sim = [item, similarity]
#
#         if not sim:
#             for item in arxiv:
#                 authors2 = item['wordlist']
#                 count = 0
#                 for word in authors2:
#                     if word in authors1:
#                         count +=1
#                 similarity = 2*float(count)/(len(authors1)+len(authors2))
#                 if similarity > value:
#                     value = similarity
#                     sim = [item, similarity]
#
#         compare = {}
#         compare['paper1'] = article
#         compare['paper2'] = sim[0]
#         compare['similarity'] = sim[1]
#
#         print i
#         if i < len(conf):
#             json_file.write(json.dumps(compare) + ',\n')
#         else:
#             json_file.write(json.dumps(compare) + '\n')
#         i += 1
#
#         txt_file.write((' '.join(article['authors'])).encode('utf-8') + '---' + str(sim[1]) + '---' + sim[0]['authors'] + '\n')
#
#     json_file.write(']')
#     json_file.close()
#     txt_file.close()






if __name__ == '__main__':

    # match_title(conference='ISCA')
    # match_authors(conference='ISCA')
    # dirs = os.listdir('/Users/Kay/Project/Scraper/conference')
    # print dirs
    # cons = []
    # for dir in dirs:
    #     if dir.endswith('.json'):
    #         con = dir.split('2')[0]
    #         if con not in cons:
    #             cons.append(con)
    # print cons
    # cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI', 'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA', 'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    # cons = ['SIGKDD', 'SIGMOD', 'STOC']

    cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI', 'FOCS', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA', 'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']
    for con in cons:
        compute_similarity(con)
    # compute_similarity('ACL')
    # compute_similarity('CCS')
    # arxiv = process_arxiv_data()
    # compute_similarity('ICML')


