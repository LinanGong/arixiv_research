__author__ = 'Kay'

import json
import pylab as pl
import datetime as dt
from matplotlib.dates import DateFormatter
import numpy as np
import logistic_model as lm

Month = {'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
         'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct':10, 'Nov':11, 'Dec':12}


def get_dates_data():
    deadlines = {}
    for line in open('/Users/Kay/Project/Scraper/analysis/deadlines.txt'):
        dates = {}
        text = line.strip().split(' : ')
        name = text[0]
        print name
        dues = text[1].split(' , ')
        for i in range(0, len(dues)):
            d = str(2015-i)
            dates[d] = dues[i]

        print dates
        deadlines[name] = dates
    return deadlines


def get_matched_data():
    cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
            'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA',
            'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    matched = {}

    for con in cons:
        with open('sim_files/' + con + '_sim.json') as f:
            papers = json.load(f)

        X = lm.get_sim_data(con)
        y = lm.apply_model(X, 'model/all.mod')

        mat = []
        for paper in papers:
            if y[papers.index(paper)] == 1:
                mat.append(paper)
        print con
        print len(mat)
        matched[con] = mat

    return matched


def compare_dates_by_conference():
    deadlines = get_dates_data()
    matched = get_matched_data()
    cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
            'FOCS', 'ICML', 'ICSE', 'NIPS', 'OOPSLA',
            'PLDI', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    i = 1
    for con in cons:
        dl = deadlines[con]
        mat = matched[con]
        S = []
        for paper in mat:
            year1 = paper['paper1']['year']
            date1 = dl[year1]
            y1 = date1.split('-')[0]
            m1 = date1.split('-')[1]
            date2 = paper['paper2']['submit']
            y2 = date2.split('-')[2]
            m2 = Month[date2.split('-')[1]]
            # print 'deadline: ', date1
            # print y2, m2

            space = (int(y2)-int(y1))*12 + (m2-int(m1))
            # print '------', space
            S.append(space)
        ax = pl.subplot(3, 5, i)
        mean = np.array(S).mean()
        std = np.array(S).std()

        n, bins, patches = ax.hist(S, 20, normed=True)

        print con
        print np.dot(np.array(n), np.array(bins))
        # print mean, std
        # print 'original data: ', S
        # print 'n: ', n
        # print 'bins: ', bins
        pl.title(con)
        i += 1

    pl.show()


def compare_dates_by_years():
    deadlines = get_dates_data()
    matched = get_matched_data()
    cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
            'FOCS', 'ICML', 'ICSE', 'NIPS', 'OOPSLA',
            'PLDI', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    Years = {'2015': [], '2014': [], '2013': [], '2012': [], '2011': [],
             '2010': [], '2009': [], '2008': [], '2007': [], '2006': []}

    for con in cons:
        dl = deadlines[con]
        mat = matched[con]

        for paper in mat:
            year1 = paper['paper1']['year']
            date1 = dl[year1]
            y1 = date1.split('-')[0]
            m1 = date1.split('-')[1]
            date2 = paper['paper2']['submit']
            y2 = date2.split('-')[2]
            m2 = Month[date2.split('-')[1]]
            print 'deadline: ', date1
            print y2, m2

            space = (int(y2)-int(y1))*12 + (m2-int(m1))
            print '------', space
            Years[year1].append(space)

    i = 1
    mean = []
    std = []
    for year in sorted(Years.keys()):
        Y = Years[year]
        mean.append(np.array(Y).mean())
        std.append(np.array(Y).std())
        print year, ' mean: ', np.array(Y).mean(), ' std: ', np.array(Y).std()
        ax = pl.subplot(2, 5, i)
        n, bins, patches = ax.hist(Y, 20, normed=True)
        print 'original data: ', Y
        print 'n: ', n
        print 'bins: ', bins
        pl.title(year)
        i += 1

    pl.show()
    # x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']
    # start = dt.datetime(2006, 1, 1)
    # dates = [start + dt.timedelta(days=i*366) for i in range(0, 10)]
    # ax2 = pl.gca()
    # ax2.plot_date(pl.date2num(dates), mean, linestyle='-', label='mean')
    # ax2.plot_date(pl.date2num(dates), std, linestyle='-', label='std')
    # pl.legend()
    # pl.show()


if __name__ == '__main__':
    compare_dates_by_conference()
    # compare_dates_by_years()