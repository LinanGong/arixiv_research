__author__ = 'Kay'

import numpy as np
import matplotlib.pyplot as plt
import pylab as pl
import datetime as dt
from matplotlib.dates import DayLocator, HourLocator, DateFormatter, drange
import preprocess


def show_trend():
    (total, pre) = preprocess.preprint_percent()
    print total, pre

    x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']

    y = []
    for i in range(0, 10):
        print float(pre[i])
        if total[i] != 0:
            y.append(format(float(pre[i])/total[i], '.2'))

    start = dt.datetime(2006, 1, 1)
    dates = [start + dt.timedelta(days=i*365) for i in range(0, 10)]

    ax = plt.gca()
    ax.xaxis.set_major_formatter(DateFormatter('%Y'))

    ax.plot_date(pl.date2num(dates), y, linestyle='-', marker='o')
    pl.title('Trend of use of arXiv on NIPS')
    pl.xlabel('year')
    pl.ylabel('percentage')

    pl.show()


def arxiv_subjects_submission():
    category = preprocess.extact_categories()
    print category
    items = category.items()
    backitems = [[v[1], v[0]] for v in items]
    backitems.sort()
    keys = [v[1] for v in backitems]
    print keys
    values = [v[0] for v in backitems]
    # key = list(category.keys())
    # value = list(category.values())
    pl.xticks(np.arange(len(keys)), keys)
    pl.bar(np.arange(len(keys)), values, align='center')
    # # pl.title('Submissions on arXiv in CS')
    pl.xlabel('sub-area')
    pl.ylabel('number of papers (1990-2015)')
    pl.show()

if __name__=='__main__':
    # show_trend()
    arxiv_subjects_submission()