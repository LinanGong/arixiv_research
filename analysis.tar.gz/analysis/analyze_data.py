__author__ = 'Kay'
import json
from nltk.corpus import stopwords
from nltk.tokenize import wordpunct_tokenize
from nltk.stem.porter import PorterStemmer
import os
import re


def load_arxiv_data():
    arxiv = []
    print "load arXiv data ..."
    for line in open('/Users/Kay/Project/Scraper/arXiv/arxiv_articles.txt'):
        item = {}
        data = line.strip().split(' ### ')
        item['title'] = data[0]
        item['authors'] = data[1]
        item['category'] = data[2]
        item['submit'] = data[3]
        arxiv.append(item)
    print "load successful"
    return arxiv


def load_nips_data():
    with open('/Users/Kay/Project/Scraper/conference/NIPS.json') as file1:
        nips = json.load(file1)
    return nips


def load_conference_data(conference):
    dirs = os.listdir('/Users/Kay/Project/Scraper/conference')
    print dirs
    conf = []
    for dir in dirs:
        if dir.startswith(conference):
            with open('/Users/Kay/Project/Scraper/conference/'+dir) as jsonfile:
                con = json.load(jsonfile)
                print con
                conf.append(con)
    return conf


def complete_match():
    arxiv = load_arxiv_data()
    nips = load_nips_data()
    complete_file = file('complete.txt', 'w')
    tag = 0
    for article in nips:

        title = article['title'][0]
        for item in arxiv:
            if title.lower() == item['title'].lower():
                tag += 1
                print 'match!\n', item['title']
                complete_file.write(title+'\n')
                break
    print tag


def remove_matched():
    arxiv = load_arxiv_data()
    arxiv2 = []
    nips = load_nips_data()
    nips2 = []
    complete = []
    for line in open('/Users/Kay/Project/Scraper/analysis/complete.txt'):
        complete.append(line.strip().lower())
    print 'load complete list'

    f = open('test.txt', 'w')
    for article in nips:

        title = article['title'][0]

        if title.lower() in complete:
            print title
            f.write(title+'\n')

        else:
            print 'incomplete'
            nips2.append(article)
    f.close()

    for item in arxiv:
        if item['title'].lower() not in complete:
            arxiv2.append(item)

    return nips2, arxiv2


def fuzzy_match1():
    (nips, arxiv) = remove_matched()
    print nips
    stop_words = set(stopwords.words('english'))
    stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])

    for article in nips:
        paper = article['title'][0] + ' '.join(article['authors'])
        paper = paper.lower()
        paper1 = [i for i in wordpunct_tokenize(paper) if i not in stop_words]
        article['paper'] = paper1
        print paper1
    print 'nips processed!'

    for item in arxiv:
        paper = item['title'] + item['authors']
        paper = paper.lower()
        paper2 = [i for i in wordpunct_tokenize(paper) if i not in stop_words]
        item['paper'] = paper2
    print 'arxiv processed!'

    out_file = open('test3.txt', 'a')
    for article in nips:
        word_count = {}
        paper1 = set(article['paper'])

        for item in arxiv:
            year = item['submit'].split('-')[2]
            if year == article['year'] or int(year) == int(article['year'])-1 or int(year) == int(article['year'])+1:
                paper2 = item['paper']

                count = 0
                for word in paper2:
                    if word in paper1:
                        count += 1
                word_count[item['title']] = 2*float(count)/(len(paper2)+len(paper1))

        v = list(word_count.values())
        print v
        k = list(word_count.keys())
        print k
        max_count = k[v.index(max(v))]
        print 'max count:', max(v), max_count


        out_file.write(article['title'][0].encode('utf-8') + '---' + str(max(v)) + '---' + max_count + '\n')

    out_file.close()


def complete_match2(conference):
    arxiv = load_arxiv_data()
    cons = load_conference_data(conference)

    json_file = open("/Users/Kay/Project/Scraper/complete/" + conference + '.json', 'w')
    json_file.write('[\n')
    for con in cons:
        complete = []
        tag = 0

        for article in con:
            title = article['title']
            for item in arxiv:
                if title.lower() == item['title'].lower():
                    tag += 1
                    print 'match!\n', item['title']
                    complete.append(article)
                    json_file.write(json.dumps(article, sort_keys=False) + ',\n')
                    break
        print tag
    json_file.write(']')
    json_file.close()


def remove_matched2(conference):
    arxiv = load_arxiv_data()
    arxiv2 = []
    cons = load_conference_data(conference)
    cons2 = []

    with open("/Users/Kay/Project/Scraper/complete/" + conference + '.json', 'r') as f:
        complete = json.load(f)

    file1 = open('acl_test.json', 'w')
    file1.write('[\n')
    for con in cons:
        for article in con:
            if article not in complete:
                cons2.append(article)
                file1.write(json.dumps(article, sort_keys=False)+',\n')
        pass
    file1.write(']')
    file1.close()

    com = []
    for paper in complete:
        com.append(paper['title'].encode('utf-8').lower())

    for item in arxiv:
        if item['title'].lower() not in set(com):
            arxiv2.append(item)

    length = 0
    for i in cons:
        length += len(i)
    print length, len(cons2)
    print len(arxiv), len(arxiv2)

    return arxiv2, cons2


def combine_title_author(conference):
    arxiv, cons = remove_matched2(conference)

    stop_words = set(stopwords.words('english'))
    stop_words.update(['.', ',', '"', "'", '?', '!', ':', ';', '-', '(', ')', '[', ']', '{', '}'])

    for item in arxiv:
        authors = re.sub(r'\(.*\)', '', item['authors'])
        paper = item['title'] + authors
        paper = paper.lower()
        paper2 = [i for i in wordpunct_tokenize(paper) if i not in stop_words]
        item['paper'] = paper2
    print 'arxiv processed!'

    for article in cons:
        paper = article['title'] + ' '.join(article['authors'])
        paper = paper.lower()
        paper1 = [i for i in wordpunct_tokenize(paper) if i not in stop_words]
        article['paper'] = paper1
        print paper1
    print conference + ' processed!'

    return arxiv, cons


def fuzzy_match2(conference):
    arxiv, cons = combine_title_author(conference)

    json_file = open('/Users/Kay/Project/Scraper/data/' + conference + '.json', 'w')
    txt_file = open('/Users/Kay/Project/Scraper/data/' + conference + '.txt', 'w')

    matched = []
    json_file.write('[\n')
    for article in cons:
        word_count = {}
        paper1 = set(article['paper'])

        for item in arxiv:
            year = item['submit'].split('-')[2]
            if year == article['year'] or int(year) == int(article['year'])-1 or int(year) == int(article['year'])+1:
                paper2 = item['paper']

                count = 0
                for word in paper2:
                    if word in paper1:
                        count += 1
                word_count[item['title']] = 2*float(count)/(len(paper2)+len(paper1))

        v = list(word_count.values())
        print v
        k = list(word_count.keys())
        print k
        max_count = k[v.index(max(v))]
        print 'max count:', max(v), max_count

        txt_file.write(article['title'].encode('utf-8') + '---' + str(max(v)) + '---' + max_count + '\n')
        if max(v) >= 7.5:
            matched.append(article)
            json_file.write(json.dumps(article) + ',\n')

    txt_file.close()
    json_file.write(']')
    json_file.close()

def check():
    with open('/Users/Kay/Project/Scraper/analysis/sim_files/ICML_sim.json') as f:
        icml = json.load(f)

    for item in icml:
        if item['paper1']['year'] == '2012':
            print item['paper1']['title']
            print item['paper2']['title']
            print item['t_sim']
            print '------------------'

if __name__=='__main__':

    # complete_match()
    # fuzzy_match1()
    # remove_matched()
    # con = raw_input('please input conference name: ')
    # load_conference_data(con)
    # fuzzy_match2(con)
    # complete_match2(con)
    # remove_matched2(con)
    check()

