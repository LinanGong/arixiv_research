__author__ = 'Kay'

import json


def load_arxiv_data():
    arxiv = []
    print "load arXiv data ..."
    for line in open('/Users/Kay/Project/Scraper/arXiv/arxiv_articles.txt'):
        item = {}
        data = line.strip().split(' ### ')
        item['title'] = data[0]
        item['authors'] = data[1]
        item['category'] = data[2]
        item['submit'] = data[3]
        arxiv.append(item)
    print "load successful"
    return arxiv


def divide_data_in_year():

    with open('/Users/Kay/Project/Scraper/conference/NIPS.json') as file1:
        nips = json.load(file1)

    nips2015 = []
    nips2014 = []
    nips2013 = []
    nips2012 = []
    nips2011 = []
    nips2010 = []
    nips2009 = []
    nips2008 = []
    nips2007 = []
    nips2006 = []

    for article in nips:
        item = {}
        item['title'] = article['title'][0]
        item['year'] = article['year']
        item['authors'] = article['authors']
        if article['year'] == '2015':
            nips2015.append(item)
        elif article['year'] == '2014':
            nips2014.append(item)
        elif article['year'] == '2013':
            nips2013.append(item)
        elif article['year'] == '2012':
            nips2012.append(item)
        elif article['year'] == '2011':
            nips2011.append(item)
        elif article['year'] == '2010':
            nips2010.append(item)
        elif article['year'] == '2009':
            nips2009.append(item)
        elif article['year'] == '2008':
            nips2008.append(item)
        elif article['year'] == '2007':
            nips2007.append(item)
        elif article['year'] == '2006':
            nips2006.append(item)

    s = 2006
    while s < 2016:
        with open('/Users/Kay/Project/Scraper/conference/NIPS'+str(s)+'.json', 'w') as f:
            obj = 'nips'+str(s)
            json.dump(eval(obj), f)

        s += 1

    n = [nips2006, nips2007, nips2008, nips2009, nips2010, nips2011, nips2012, nips2013, nips2014, nips2015]

    return n


def preprint_percent():

    complete = []
    for line in open('/Users/Kay/Project/Scraper/analysis/complete.txt'):
        complete.append(line.strip())

    n = divide_data_in_year()
    total_count = []
    preprint_count = []

    for i in range(0, 10):

        count = 0
        total_count.append(len(n[i]))
        for item in n[i]:
            if item['title'] in complete:
                count += 1
        preprint_count.append(count)
        print i, count

    return total_count, preprint_count


def extact_categories():
    arxiv = load_arxiv_data()
    category = {}
    for paper in arxiv:
        cate = paper['category'].split()

        for area in cate:
            if area.startswith('cs.'):
                sub = area.split('.')[1]
                if sub in category:
                    category[sub] += 1
                else:
                    category[sub] = 1
    return category


def divide_conference_data(conf):
    with open('/Users/Kay/Project/Scraper/conference/'+conf+'.json') as f:
        obj = json.load(f)

    con2015 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2015.json', 'w')
    con2014 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2014.json', 'w')
    con2013 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2013.json', 'w')
    con2012 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2012.json', 'w')
    con2011 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2011.json', 'w')
    con2010 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2010.json', 'w')
    con2009 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2009.json', 'w')
    con2008 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2008.json', 'w')
    con2007 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2007.json', 'w')
    con2006 = open('/Users/Kay/Project/Scraper/conference/'+conf+'2006.json', 'w')

    con2015.write('[\n')
    con2014.write('[\n')
    con2013.write('[\n')
    con2012.write('[\n')
    con2011.write('[\n')
    con2010.write('[\n')
    con2009.write('[\n')
    con2008.write('[\n')
    con2007.write('[\n')
    con2006.write('[\n')

    for article in obj:
        if article['year'] == '2015':
            con2015.write(json.dumps(article) + ',\n')
        elif article['year'] == '2014':
            con2014.write(json.dumps(article) + ',\n')
        elif article['year'] == '2013':
            con2013.write(json.dumps(article) + ',\n')
        elif article['year'] == '2012':
            con2012.write(json.dumps(article) + ',\n')
        elif article['year'] == '2011':
            con2011.write(json.dumps(article) + ',\n')
        elif article['year'] == '2010':
            con2010.write(json.dumps(article) + ',\n')
        elif article['year'] == '2009':
            con2009.write(json.dumps(article) + ',\n')
        elif article['year'] == '2008':
            con2008.write(json.dumps(article) + ',\n')
        elif article['year'] == '2007':
            con2007.write(json.dumps(article) + ',\n')
        elif article['year'] == '2006':
            con2006.write(json.dumps(article) + ',\n')

    con2015.write(']')
    con2014.write(']')
    con2013.write(']')
    con2012.write(']')
    con2011.write(']')
    con2010.write(']')
    con2009.write(']')
    con2008.write(']')
    con2007.write(']')
    con2006.write(']')


if __name__=='__main__':
    divide_conference_data('AAAI')


