__author__ = 'Kay'
import json
import pylab as pl
import logistic_model as lm


Month = {'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
         'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct':10, 'Nov':11, 'Dec':12}

def matched_dates():
    with open('/Users/Kay/Project/Scraper/analysis/sim_files/ICML_sim.json') as f:
        icml = json.load(f)

    X = lm.get_sim_data('ICML')
    y = lm.apply_model(X, 'model/all.mod')

    icml2012 = {}
    Jun = {}
    for item in icml:
        if item['paper1']['year'] == '2012' and y[icml.index(item)] == 1:
            submit = item['paper2']['submit'].split('-')
            year = submit[2]
            mon = Month[submit[1]]
            day = submit[0]
            print year, mon, item['paper2']['submit']
            date = year+'-'+str(mon)
            if date in icml2012:
                icml2012[date] += 1
            else:
                icml2012[date] = 1

            if year=='2012' and mon == 6:
                d = year + '-' + str(mon) + '-' + day
                if d in Jun:
                    Jun[d] += 1
                else:
                    Jun[d] = 1

    print icml2012
    print Jun


if __name__ == '__main__':
    matched_dates()