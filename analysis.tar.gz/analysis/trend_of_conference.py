__author__ = 'Kay'

import json
import pylab as pl
import datetime as dt
from matplotlib.dates import DateFormatter
import numpy as np
import logistic_model as lm
# import seaborn as sns
#
# sns.set(style='whitegrid')
# sns.set_palette('muted')


def select_matched_papers(conference):

    with open('data_files/'+conference+'_title.json') as f1:
        title = json.load(f1)
    with open('data_files/'+conference+'_authors.json') as f2:
        authors = json.load(f2)

    published = {}
    matched = {}
    for i in range(0, len(title)):
        year = title[i]['paper1']['year']
        if year in published:
            published[year] += 1
        else:
            published[year] = 1.0
        if year not in matched:
            matched[year] = 0
        if title[i]['similarity'] >= 0.85 and authors[i]['similarity'] >= 0.7:
            matched[year] += 1

    proportion = {}
    for year in published:
        proportion[year] = matched[year]/published[year]

    return proportion, matched, published


def get_matched_data():
    # cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
    #         'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA',
    #         'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']
    cons = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
             'ICSE', 'OOPSLA',
            'PLDI', 'SIGIR', 'SIGKDD', 'SIGMOD']
    # cons = ['AAAI', 'AAMAS', 'ACL', 'SIGKDD']
    cons = ['CCS', 'SIGMOD', 'SIGIR']
    cons = ['CHI', 'ICSE', 'OOPSLA', 'PLDI']

    published = []
    matched = []
    proportion = []

    for con in cons:
        with open('sim_files/' + con + '_sim.json') as f:
            papers = json.load(f)

        X = lm.get_sim_data(con)
        y = lm.apply_model(X, 'model/all.mod')
        pub = {}
        mat = {}
        pro = {}
        for paper in papers:
            year = paper['paper1']['year']
            if year in pub:
                pub[year] += 1
            else:
                pub[year] = 1.0
            if year not in mat:
                mat[year] = 0.0
            if y[papers.index(paper)] == 1:
                mat[year] += 1
        published.append(pub)
        matched.append(mat)

        for year in pub:
            pro[year] = mat[year]/pub[year]
        proportion.append(pro)

    return published, matched, proportion


def plot_proportion_trend(cons):
    # conferences = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
    #         'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA',
    #         'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']
    conferences = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
             'ICSE', 'ISCA', 'OOPSLA',
            'PLDI', 'SIGIR', 'SIGKDD', 'SIGMOD']
    # conferences = ['AAAI', 'AAMAS', 'ACL', 'SIGKDD']
    conferences = ['CCS', 'SIGMOD', 'SIGIR']
    conferences = ['CHI', 'ICSE', 'OOPSLA', 'PLDI']

    markers = ['o', '*', 'd', 's', '>',
              ',', 'x', '1', '2', '<', '3',
              '4', '|', 'h', 'H', '+', '^']

    for con in cons:
        label = conferences[cons.index(con)]
        marker = markers[cons.index(con)]
        print label
        x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']
        y = []
        for year in x:
            if year in con:
                y.append(con[year])
            else:
                y.append(0)
        print y
        # for i, j in globals().items():
        #     if con == j and i != 'con':
        #         var = i
        #         print var, type(var)
        start = dt.datetime(2006, 1, 1)
        dates = [start + dt.timedelta(days=i*366) for i in range(0, 10)]
        ax = pl.gca()
        ax.xaxis.set_major_formatter(DateFormatter('%Y'))
        ax.plot_date(pl.date2num(dates), y, linewidth=2.0, linestyle='-', marker=marker, label=label)
        pl.legend(loc='upper left')
        # pl.title('Trend of proportion in the use of Arxiv for recent 10 years')
        pl.xlabel('year')
        pl.ylabel('percentage')

    pl.show()


def plot_pub_trend(cons):

    for con in cons:

        x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']
        y = []
        for year in x:
            if year in con:
                y.append(con[year])
            else:
                y.append(0)
        for i, j in globals().items():
            if con == j and i != 'con':
                var = i
                print var, type(var)
        start = dt.datetime(2006, 1, 1)
        dates = [start + dt.timedelta(days=i*365) for i in range(0, 10)]
        ax = pl.gca()
        ax.xaxis.set_major_formatter(DateFormatter('%Y'))
        ax.plot_date(pl.date2num(dates), y, linewidth=2.0, linestyle='-', label=var.replace('_pro', ''))
        pl.legend(loc='upper left')
        pl.title('Trend of accepted papers in recent 10 years')
        pl.xlabel('year')
        pl.ylabel('number of papers')

    pl.show()


def plot_matched_trend(cons):
    conferences = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
            'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA',
            'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    markers = ['o', ',', '^', '<', '>',
              '*', 'x', '1', '2', '+', '3',
              '4', '|', 'h', 'H', 's', 'd']

    x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']
    start = dt.datetime(2006, 1, 1)
    dates = [start + dt.timedelta(days=i*366) for i in range(0, 10)]

    for con in cons:
        name = conferences[cons.index(con)]
        marker = markers[cons.index(con)]
        print name

        y = []
        for year in x:
            if year in con:
                y.append(con[year])
            else:
                y.append(0)
        print y
        ax = pl.gca()
        # ax.xaxis.set_major_formatter(DateFormatter('%Y'))
        ax.plot_date(pl.date2num(dates), y, linewidth=2.0, linestyle='-', marker=marker, label=name)
        pl.legend(loc='upper left')
        # pl.title('Trend of matched paper in the use of Arxiv for recent 10 years')
        pl.xlabel('year')
        pl.ylabel('number of papers')

    pl.show()


def plot_total_matched_pub(cons1, cons2):
    conferences = ['AAAI', 'AAMAS', 'ACL', 'CCS', 'CHI',
            'FOCS', 'ICML', 'ICSE', 'ISCA', 'NIPS', 'OOPSLA',
            'PLDI', 'SIGGRAPH', 'SIGIR', 'SIGKDD', 'SIGMOD', 'STOC']

    matched = []
    published = []
    M = {}
    P = {}
    for con in cons1:
        matched.append(sum(con.values()))

    for con in cons2:
        published.append(sum(con.values()))
    print matched
    print published

    for c in conferences:
        M[c] = matched[conferences.index(c)]
        P[c] = published[conferences.index(c)]
    items = M.items()
    backitems = [[v[1], v[0]] for v in items]
    backitems.sort()
    matched = [v[0] for v in backitems]
    name = [v[1] for v in backitems]
    published = [P[c] for c in name]
    print name
    print matched
    print published
    groups = len(cons1)
    index = np.arange(groups)
    bar_width = 0.35
    opacity = 0.5
    fig, ax = pl.subplots()
    rect1 = pl.bar(index, matched, bar_width, alpha=opacity, color='r', label='submit on arXiv')
    rect2 = pl.bar(index+bar_width, published, bar_width, alpha=opacity, color='b', label='accepted papers')
    pl.xticks(index + bar_width, name)
    # pl.title('The total papers for recent 10 years')
    pl.legend(loc='upper left')
    pl.show()


def get_group_proportion(cons):
    published = {}
    matched = {}
    proportion = {}
    for con in cons:
        with open('sim_files/' + con + '_sim.json') as f:
            papers = json.load(f)

        X = lm.get_sim_data(con)
        y = lm.apply_model(X, 'model/all.mod')

        for paper in papers:
            year = paper['paper1']['year']
            if year in published:
                published[year] += 1
            else:
                published[year] = 1.0
            if year not in matched:
                matched[year] = 0.0
            if y[papers.index(paper)] == 1:
                matched[year] += 1

    for year in published:
        proportion[year] = matched[year]/published[year]

    return proportion


def plot_groups_proportion():
    groups = {'AR': ['ISCA'], 'AI': ['AAAI', 'AAMAS', 'ACL', 'NIPS', 'ICML'], 'SE': ['ICSE', 'OOPSLA', 'PLDI'],
              'CG': ['SIGGRAPH'], 'DM': ['SIGMOD', 'SIGKDD', 'SIGIR'], 'TH': ['FOCS', 'STOC'],
              'CS': ['CCS'], 'HCI': ['CHI']}

    markers = ['o', '*', 'd', 's', '+', 'x', '<', '^']

    x = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015']
    start = dt.datetime(2006, 1, 1)
    dates = [start + dt.timedelta(days=i*366) for i in range(0, 10)]

    index = 0

    for group in groups:
        print group
        cons = groups[group]
        print cons
        proportion = get_group_proportion(cons)
        y = []
        for year in x:
            y.append(proportion[year])
        ax = pl.gca()
        ax.plot_date(pl.date2num(dates), y, linewidth=2.0, linestyle='-', marker=markers[index], label=group)
        pl.legend(loc='upper left')

        index += 1
    pl.show()


if __name__=='__main__':
    # NIPS_pro, NIPS_matched, NIPS_pub = select_matched_papers('NIPS')
    # ACL_pro, ACL_matched, ACL_pub = select_matched_papers('ACL')
    # AAAI_pro, AAAI_matched, AAAI_pub = select_matched_papers('AAAI')
    # AAMAS_pro, AAMAS_matched, AAMAS_pub = select_matched_papers('AAMAS')
    # ICML_pro, ICML_matched, ICML_pub = select_matched_papers('ICML')
    # FOCS_pro, FOCS_matched, FOCS_pub = select_matched_papers('FOCS')
    #
    # # cons_pro = [NIPS_pro, ACL_pro, AAAI_pro, AAMAS_pro, ICML_pro, FOCS_pro]
    # # plot_proportion_trend(cons_pro)
    #
    # cons_matched = [NIPS_matched, ACL_matched, AAAI_matched, AAMAS_matched, ICML_matched, FOCS_matched]
    # # plot_matched_trend(cons_matched)
    # cons_pub = [NIPS_pub, ACL_pub, AAAI_pub, AAMAS_pub, ICML_pub, FOCS_pub]
    # # plot_pub_trend(cons_pub)
    # plot_total_matched_pub(cons_matched, cons_pub)

    published, matched, proportion = get_matched_data()
    plot_proportion_trend(proportion)
    # plot_matched_trend(matched)
    # plot_total_matched_pub(matched, published)
    # plot_groups_proportion()




